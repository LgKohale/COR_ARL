<html>
<body>
<div id ="output" > </div>

<script type= "text/javascript"></script>
<script>
var output= document.getElementById('output');
var ajaxhttp= new XMLHttpRequest();
var url= " https://api.myjson.com/bins/23xvb";

ajaxhttp.open("GET",url,true);
ajaxhttp.setRequestHeader("content-type","application/json");
ajaxhttp.onreadystatechange= function(){
		if(ajaxhttp.readyState==4 && ajaxhttp.status==200){
			var jcontent=JSON.parse(ajaxhttp.responseText);
			output.innerHTML = jcontent.firstName+ ' ' + jcontent.lastName + ' '+
			jcontent.phoneNumbers[1].type+ ' ' + jcontent.address.city;
			jcontent.address.city ="Toronto";
			console.log(jcontent);
		}
}	


</script>
</body>
</html>