/* var http = require("http");
var server = http.createServer(function(request, response) {
  response.writeHead(200, {"Content-Type": "text/html"});
  // response.write("<!DOCTYPE "html">");
  response.write("<html>");
  response.write("<head>");
  response.write("<title>Hello World Page</title>");
  response.write("</head>");
  response.write("<body>");
  response.write("Hello World!");
  response.write("</body>");
  response.write("</html>");
  response.end('HELLO');
});

server.listen(8080);
console.log("Server is listening"); */

/* var app = require('http').createServer(response);
app.listen(8080);
console.log("App running…");
function response(req, res) {
 res.writeHead(200);
 res.end("Hi, your server is working!");
} */

var app = require('http').createServer(response);
var fs = require('fs');
app.listen(8080);
console.log("App running…!!!");
function response(req, res) {
 fs.readFile(__dirname + '/index.html',
 function (err, data) {
 if (err) {
   res.writeHead(500);
   return res.end('Failed to load file index.html');
 }
 res.writeHead(200);
   res.end(data);
 });
}