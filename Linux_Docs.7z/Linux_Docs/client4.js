var http = require('http');
var EventSource = require('eventsource');

es = new EventSource('http://localhost:8080');
/* es.onmessage = function(e) {
    console.log(e.data);
}; */
 es.onerror = function() {
    console.log('ERROR!');
};  
es.onopen = function() {
    console.log('!!!!!!');
}; 
es.addEventListener('open', function(e) {
  // Connection was opened.
  console.log('Connected');
}, false);
/* es.addEventListener('message', function(e) {
  console.log(e.data);
  console.log('conn');
}, false); */
es.addEventListener('userlogon', function(e) {
  var data = JSON.parse(e.data);
  console.log('User login:' + data.username);
}, false);

<!-- <html>
<body>
<h1>To get server updates, Click here</h1>
<a href="http://localhost:8080/events">Updates</a>
</body>
</html> -->