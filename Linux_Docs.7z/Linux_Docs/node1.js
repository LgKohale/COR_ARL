var http = require('http');
var dt=require('./myDate');
http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain'});
	res.write("The date and time are currently: "+dt.myDateTime());
    res.end('Hello Node.js World!...');
}).listen(8080);
console.log('server listen on port 8080');