var events = require('events');
var eventEmitter = new events.EventEmitter();

//Create an event handler:
var myEventHandler = function () {
  console.log('I hear a scream!');
}

//Assign the eventhandler to an event:
eventEmitter.on('scream', myEventHandler);

//Fire the 'scream' event:
eventEmitter.emit('scream');


<!DOCTYPE html>
<html>
<body>

<p>Click the button to convert the string to uppercase letters.</p>

<button onclick="myFunction()">Try it</button>

<p id="demo"></p>

<script>
function myFunction() {
  var str = "Hello World!";
  var res = str.toUpperCase();
  document.getElementById("demo").innerHTML = res;
}
</script>

</body>
</html>