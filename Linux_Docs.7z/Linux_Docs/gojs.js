

var http = require('http');
var sys = require('util');
var fs = require('fs');
var obj;

http.createServer(function(req, res) {
	if (req.headers.accept && req.headers.accept == 'text/event-stream') {
    if (req.url == '/events') {
      sendSSE(req, res);
    } else {
      res.writeHead(404);
      res.end();
    }
	}
}).listen(8080);

function sendSSE(req, res) {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive'
  });
  var id=1;
fs.readFile('weather1.json', 'utf8', function (err, data) {
  if (err) throw err;
  obj = JSON.parse(data);
  constructSSE(res, id, obj);
  console.log(obj);
  res.write(obj);
});
 
}
function constructSSE(res, id, obj) {
  res.write('id: ' + id + '\n');
  res.write("data: " + obj + '\n\n');
  console.log(obj);
}


