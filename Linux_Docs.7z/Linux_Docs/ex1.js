<html>
<body>

<div id="id01"></div>
<script>
function myFunction(arr) {
  var out = "";
  var i;
  for(i = 0; i<arr.length; i++) {
    out += '<a href="' + arr[i].url + '">' + 
    arr[i].display + '</a><br>';
  }
  document.getElementById("id01").innerHTML = out;
}
</script>

<script src="C:/Users/lkohale/Desktop/Latika/Linux_Docs/weather1.json"></script>

</body>
</html>