var http = require('http');
var server = http.createServer((req, res) => {
    res.end(`
		
        <html>
        <body>
            <form action="/" method="post">
                <input type="text" name="location" /><br />
                <button>Show</button>
            </form>
        </body>
        </html>
    `);
});
server.listen(8080);