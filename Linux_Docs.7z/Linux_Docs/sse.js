var http = require('http');

http.createServer(function (request, response) {

  response.writeHead(200, {
     'Content-Type': 'text/plain'
  });

  response.end('Hello HTTP!');
  let id = 1;
  // Send event every 3 seconds or so forever...
  setInterval(() => {
    response.write(
      `event: myEvent\nid: ${id}\ndata:This is event ${id}.`
    );
    response.write('\n\n');
    id++;
  }, 3000);
}).listen(8080);

/* var EventSource = require('eventsource');

var sseSource = new EventSource('http://localhost:8080');

sseSource.addEventListener('message', (e) => {
    const messageData = e.data;
    console.log(messageData);
	console.log('SSE');
});
sseSource.onerror = function (err) {
  if (err) {
    if (err.status === 401 || err.status === 403) {
      console.log('not authorized');
    }
  }
}

// When finished with the source close the connection
sseSource.close(); */




