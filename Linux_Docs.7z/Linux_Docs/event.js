var EventSource = require('eventsource');

var esSource={  headers: {Authorization: "Bearer your_access_token"}
};
var url = "http://localhost: 8080" ;
var es= new EventSource(url, esSource);
console.log('Hello!!!');
es.addEventListener('Hello' , (e) => {
    const messageData = e.data;
    console.log(messageData);
	console.log('SSE');
});
console.log('Hello!22!!');
es.close();
console.log('Hello!!!');