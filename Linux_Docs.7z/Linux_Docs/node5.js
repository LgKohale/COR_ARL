/* function myData() {
return "hello"; }
console.log(myData());
function hello(name) {
console.log("hello " + name); }
hello("Node.js"); */

/* var x= function(a, b) {
	 return a+b;
}
console.log(x(10,20));
console.log(null == undefined);
 */
function fine(param) {
	if(param==null || param==undefined)
		console.log("true");
		throw new Error("Invalid arguments");
}
function better(param) {
	if(!param)
		throw new Error("invalid agument");
}
var param=' ';