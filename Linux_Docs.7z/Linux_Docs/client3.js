/*  var SSE = require('sse')
  , http = require('http');
 
var server = http.createServer(function(req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('okay');
});
 
server.listen(8080, '127.0.0.1', function() {
  var sse = new SSE(server);
  sse.on('connection', function(client) {
    client.send('hi there!');
  });
}); */
/*var EventSource = require('eventsource');
var es = new EventSource("/sse");
es.onmessage = function (event) {
  console.log(event.data);
};  */

/* var EventSource = require('eventsource');

es = new EventSource('http://localhost');
es.onmessage = function(e) {
    console.log(e.data);
};
es.onerror = function() {
    console.log('ERROR!');
}; */

var http = require('http');
var sys = require('util');
var fs = require('fs');
http.createServer(function (request, response) {
response.writeHead(200, {
     'Content-Type': 'text/plain'
  });

 let id = 1;
  // Send event every 3 seconds or so forever...
  setInterval(() => {
    response.write(
      `event: myEvent\nid: ${id}\ndata:This is Event ${id}.`
    );
    response.write('\n\n');
    id++;
  }, 3000);
  
  
}).listen(8080);

/* function sendSSE(request, response) {
  response.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive'
  });

  var id = (new Date()).toLocaleTimeString();

  // Sends a SSE every 5 seconds on a single connection.
  setInterval(function() {
    constructSSE(response, id, (new Date()).toLocaleTimeString());
  }, 5000);

  constructSSE(response, id, (new Date()).toLocaleTimeString());
}

function constructSSE(response, id, data) {
  response.write('id: ' + id + '\n');
  response.write("data: " + data + '\n\n');
}

function debugHeaders(request) {
  sys.puts('URL: ' + request.url);
  for (var key in request.headers) {
    sys.puts(key + ': ' + request.headers[key]);
  }
  sys.puts('\n\n');
}
if (request.headers.accept && request.headers.accept == 'text/event-stream') {
    if (request.url == '/events') {
      sendSSE(request, response);
    } else {
      response.writeHead(404);
      response.end();
    }
  } */