

var fs = require('fs');
fs.readFile('C:/Users/lkohale/Desktop/Latika/Linux_Docs/weather1.json', (err, data) => {
  if (err) {
    console.error(err);
    return
  }
  let w= JSON.parse(data);
  console.log(w); 
  console.log(w.wind);

});