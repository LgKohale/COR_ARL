
<html>
<body>
<h2>Weather Results:</h2>
<div id="weather"></div>
<script type="text/javascript" src="gojs.js"></script>
<script>
var source= new Eventsource('http://localhost:8080');
source.onmessage = function(event) {
let wea= JSON.parse(event.data);
document.getElementById("weather").innerHTML += wea.location + "<br>";
</script>
</body>
</html>